/*	numbers.c
 *	From D.B. Wagner, "Power Programming with Mathematica:
 *		The Kernel." McGraw-Hill, 1996.
 *	Copyright 1996, David B. Wagner. All rights reserved.
 */

#include "mathlink.h"
#include "string.h"

void getinteger( /* void */ )
{
	char *s;
	unsigned long x;
	char s2[20];
	
	if (MLGetString( stdlink, &s ) && (sscanf(s, "%lu", &x )==1)){
		MLPutNext( stdlink, MLTKINT );
		sprintf(s2, "%lu", x);
		MLPutString( stdlink, s2 );
	}
	else {
		MLClearError( stdlink );
		MLPutSymbol( stdlink, "$Failed" );
	}
}

int main(argc, argv)
	int argc; char* argv[];
{
	return MLMain(argc, argv);
}
