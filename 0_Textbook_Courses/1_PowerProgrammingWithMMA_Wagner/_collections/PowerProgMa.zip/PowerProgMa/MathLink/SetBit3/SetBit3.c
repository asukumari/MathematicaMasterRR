/*	SetBit3.c
 *	From D.B. Wagner, "Power Programming with Mathematica:
 *		The Kernel." McGraw-Hill, 1996.
 *	Copyright 1996, David B. Wagner. All rights reserved.
 */

#include "mathlink.h"

int  setbit( int num, int bits[], long nbits )
{	int i;
	for (i = 0; i < nbits; i++)
		num |= (1<<bits[i]);
	return num;
}

int clearbit( int num, int bits[], long nbits )
{	int i;
	for (i = 0; i < nbits; i++)
		num &= ~(1<<bits[i]);
	return num;
}

int main( int argc, char **argv )
{
	return MLMain(argc, argv);
}
