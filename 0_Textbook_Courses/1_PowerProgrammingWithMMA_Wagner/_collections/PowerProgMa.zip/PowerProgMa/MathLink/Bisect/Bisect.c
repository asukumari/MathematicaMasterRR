/*	Bisect.c
 *	From D.B. Wagner, "Power Programming with Mathematica:
 *		The Kernel." McGraw-Hill, 1996.
 *	Copyright 1996, David B. Wagner. All rights reserved.
 */

#include "mathlink.h"
#include <stddef.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>

int sign(double d)
{
	if (d < 0) return -1;
	if (d > 0) return 1;
	return 0;
}

double evaluate_expr(char *buf, char *expr, char *x, double xval)
{
	double result;

#ifdef notdef
	/*  Here's the easy way to send an expression to the kernel */
	sprintf(buf, "N[%s /. %s->%f]", expr, x, xval);
	MLEvaluate( stdlink, buf );
#endif
	/* Here's the hard way to send an expression to the kernel */
	MLPutFunction(stdlink, "EvaluatePacket", 1);
	  MLPutFunction(stdlink, "N", 1);
		MLPutFunction(stdlink, "ReplaceAll", 2);
		  MLPutFunction(stdlink, "ToExpression", 1);
			MLPutString(stdlink, expr);
		  MLPutFunction(stdlink, "Rule", 2);
			MLPutSymbol(stdlink, x);
			MLPutDouble(stdlink, xval);
	MLEndPacket(stdlink);

	MLNextPacket( stdlink );
	MLGetDouble( stdlink, &result );
	return result;
}

double bisect(char *expr, char *x, double x0, double x1)
{
	double xmid;
	double y0, y1, ymid;
	
	char *buf = malloc(strlen(expr) + strlen(x) + 100);
	
	y0 = evaluate_expr(buf, expr, x, x0);
	y1 = evaluate_expr(buf, expr, x, x1);
		
	while (fabs(x1-x0) > .000001)
	{
		xmid = (x0+x1)/2.0;
		ymid = evaluate_expr(buf, expr, x, xmid);
		
		if (sign(ymid) == sign(y0))
			x0 = xmid, y0 = ymid;
		else
			x1 = xmid, y1 = ymid;
	}
	
	free(buf);
	
	return (fabs(y0) < fabs(y1)) ? x0 : x1;
}


int main(argc, argv)
	int argc; char* argv[];
{
	return MLMain(argc, argv);
}
