/*	hello.c
 *	From D.B. Wagner, "Power Programming with Mathematica:
 *		The Kernel." McGraw-Hill, 1996.
 *	Copyright 1996, David B. Wagner. All rights reserved.
 */

#include <stdio.h>
#include <console.h>
#include "mathlink.h"

main(int argc, char **argv)
{
	MLEnvironment mlenv;
	MLINK mlink;
	
	argc = ccommand(&argv);
	
	mlenv = MLInitialize( (MLParametersPointer)0 );
	if (mlenv == (MLEnvironment)0) return 1;
	
	mlink = MLOpen( argc, argv );
	if (mlink == (MLINK)0) {
		MLDeinitialize(mlenv);
		return 1;
	}
	
	
	/*** THE ACTION IS ALL HERE ***/
	MLPutString(mlink, "Hello world!");
	/******************************/

	MLGetNext(mlink);
	MLClose(mlink);
	MLDeinitialize(mlenv);
	return 0;
}
