/*	SetBit.c
 *	From D.B. Wagner, "Power Programming with Mathematica:
 *		The Kernel." McGraw-Hill, 1996.
 *	Copyright 1996, David B. Wagner. All rights reserved.
 */

#include "mathlink.h"

int  setbit( int x, int y )
{	
	return x | (1<<y);
}

int clearbit( int x, int y )
{
	return x & ~(1<<y);
}

int main( int argc, char **argv )
{
	return MLMain(argc, argv);
}
