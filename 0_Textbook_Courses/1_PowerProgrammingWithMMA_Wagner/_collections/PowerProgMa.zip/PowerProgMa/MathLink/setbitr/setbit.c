/*	setbit.c
 *	From D.B. Wagner, "Power Programming with Mathematica:
 *		The Kernel." McGraw-Hill, 1996.
 *	Copyright 1996, David B. Wagner. All rights reserved.
 */
   

#include <stdio.h>
#include <console.h>
#include <string.h>
#include "mathlink.h"


long setbit(long x, int y)
{
	printf("setbit(%ld, %d) -> %ld\n",
		x, y, x | 1<<y);
	return x | 1<<y;
}

long clearbit(long x, int y)
{
	printf("clearbit(%ld, %d) -> %ld\n",
		x, y, x & ~ (1<<y));
	return x & ~(1<<y);
}

main(int argc, char **argv)
{
	MLEnvironment mlenv;
	MLINK mlink;
	int result;
	long x;
	int y;
	char *func;
	
	mlenv = MLInitialize( (MLParametersPointer)0 );
	if (mlenv == (MLEnvironment)0) return 1;
	
	mlink = MLOpen( argc, argv );
	if (mlink == (MLINK)0) {
		MLDeinitialize(mlenv);
		return 1;
	}
	
	
	/*** THE ACTION IS ALL HERE ***/
	while (MLGetString(mlink, &func) &&
		   MLGetLongInteger(mlink, &x) &&
		   MLGetInteger(mlink, &y))
	{
		if (!strcmp(func, "setbit"))
			MLPutLongInteger(mlink, setbit(x, y));
		else if (!strcmp(func, "clearbit"))
			MLPutLongInteger(mlink, clearbit(x, y));
		else
			MLPutSymbol(mlink, "$Failed");
   		 MLDisownString(mlink, func);
	}
	/******************************/

	MLClose(mlink);
	MLDeinitialize(mlenv);
	return 0;
}
