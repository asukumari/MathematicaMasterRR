/*	BitVector4.c
 *	From D.B. Wagner, "Power Programming with Mathematica:
 *		The Kernel." McGraw-Hill, 1996.
 *	Copyright 1996, David B. Wagner. All rights reserved.
 */

#include "mathlink.h"
#include <stddef.h>
#include <stdlib.h>

/* Format of bit vector: BitVector[nbits, {bytecode..}].
 */

int		bitsPerWord = 8;

int  packbits( bits, nbits)
	int     bits[];
	long	nbits;
{	
	long	nwords = (nbits + bitsPerWord - 1) / bitsPerWord;
	int		*data = (int*) calloc(nwords, sizeof(int));
	int		i;
		
	for (i = 0; i <nbits; i++) {
		data[i / bitsPerWord] |= (bits[i] <<
			(bitsPerWord - 1 - i % bitsPerWord));
	}
	
	MLPutFunction( stdlink, "BitVector", 2);		/* head + 2 arguments */
		MLPutInteger( stdlink, nbits );				/* first argument */
		MLPutIntegerList( stdlink, data, nwords );	/* second argument */
	
	free(data);
}

void unpackbits( /* Manual */ )
{
	char	*head;
	long	count;
	long	nbits;
	int     *data;
	long	nwords;
	int		*bits;
	int		i;
	
	i = MLGetFunction( stdlink, &head, &count );
	i = MLGetLongInteger( stdlink, &nbits );
	i = MLGetIntegerList( stdlink, &data, &nwords );

	bits = (int*)malloc(nbits*sizeof(int));

	for( i = 0; i < nbits; i++)
		bits[i] = (data[i / bitsPerWord] >>
			(bitsPerWord - 1 - i % bitsPerWord)) & 1;

	MLDisownIntegerList(stdlink, data, nwords);

	MLPutIntegerList( stdlink, bits, nbits );
	
	free(bits);
}

/* In the following two functions, we assume that checking
 * for a valid bitnum is done by Mathematica code.
 */

int getbit( byte, bitnum )
	int byte;
	int bitnum;
{
	return (byte >> (bitsPerWord - bitnum)) & 1;
}

int setbit( byte, newbit, bitnum )
	int byte;
	int newbit;
	int bitnum;
{
	int mask = 1 << (bitsPerWord - bitnum);
	if (newbit == 1)
		return byte |= mask;
	else
		return byte &= ~mask;
}	


int main(argc, argv)
	int argc; char* argv[];
{
	return MLMain(argc, argv);
}
