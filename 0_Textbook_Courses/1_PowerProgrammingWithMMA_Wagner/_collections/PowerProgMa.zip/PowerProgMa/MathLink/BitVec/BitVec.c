/*	BitVector.c
 *	From D.B. Wagner, "Power Programming with Mathematica:
 *		The Kernel." McGraw-Hill, 1996.
 *	Copyright 1996, David B. Wagner. All rights reserved.
 */

#include "mathlink.h"
#include <stddef.h>
#include <stdlib.h>

/* Format of bit vector: a list of ints, where the first int in the
 * list indicates the total number of valid bits. We pack a maximum
 * of 8 bits into each int to make conversion to characters easier.
 */

int		bitsPerWord = 8;

int  packbits( bits, nbits)
	int     bits[];
	long	nbits;
{	
	long	nints = (nbits + bitsPerWord - 1) / bitsPerWord + 1;
	int		*bitvec = (int*) calloc(nints, sizeof(int));
	int		i;
	
	bitvec[0] = nbits;
	
	for (i = 0; i <nbits; i++) {
		bitvec[i / bitsPerWord + 1] |= (bits[i] <<
			(bitsPerWord - 1 - i % bitsPerWord));
	}
	
	MLPutIntegerList( stdlink, bitvec, nints );
	
	free(bitvec);
}

void unpackbits( bitvec, nints )
	int     bitvec[];
	long	nints;
{
	int		nbits = bitvec[0];
	int		*bits = (int*)malloc(nbits*sizeof(int));
	int		i;

	for( i = 0; i < nbits; i++)
		bits[i] = (bitvec[i / bitsPerWord + 1] >>
			(bitsPerWord - 1 - i % bitsPerWord)) & 1;

	MLPutIntegerList( stdlink, bits, nbits);
	
	free(bits);
}

int main(argc, argv)
	int argc; char* argv[];
{
	return MLMain(argc, argv);
}
