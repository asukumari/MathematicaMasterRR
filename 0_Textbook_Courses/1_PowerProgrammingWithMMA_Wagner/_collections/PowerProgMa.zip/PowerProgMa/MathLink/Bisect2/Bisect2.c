/*	Bisect2.c
 *	From D.B. Wagner, "Power Programming with Mathematica:
 *		The Kernel." McGraw-Hill, 1996.
 *	Copyright 1996, David B. Wagner. All rights reserved.
 */

#include "mathlink.h"
#include <stddef.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>

int sign(double d)
{
	if (d < 0) return -1;
	if (d > 0) return 1;
	return 0;
}

int evaluate_expr(char *buf, char *expr, char *x, double xval, double *result)
{
	int p, err;

	sprintf(buf, "N[%s/.%s->%f]", expr, x, xval);
	MLEvaluate( stdlink, buf );

#ifdef bogus
	MLNextPacket( stdlink );
	MLGetReal( stdlink, result);
#endif

	while ((p = MLNextPacket(stdlink)) && p != RETURNPKT)
		MLNewPacket(stdlink);

	if (p == RETURNPKT) {

		if (MLGetType( stdlink ) == MLTKREAL)
				MLGetDouble( stdlink, result );

		else {	/* wrong type! */
			
			MLNewPacket(stdlink);		/* throw it away */
			/* issue the infamous "plnr" message */
			sprintf(buf, "Message[Bisect::plnr, %s, %s, %f]",
					expr, x, xval);
			MLEvaluate(stdlink, buf);

#ifdef notdef
			/* Here's the hard way to issue the error message,
			   just for purposes of comparison.
			*/
			MLPutFunction(stdlink, "EvaluatePacket", 1);
				MLPutFunction(stdlink, "Message", 4);
					MLPutFunction(stdlink, "MessageName", 2);
						MLPutSymbol(stdlink, "Bisect");
						MLPutString(stdlink, "plnr");
					/* plnr takes three strings: expr, x, and xval */
					MLPutString(stdlink, expr);
					MLPutString(stdlink, x);
					sprintf(buf, "%f", xval);
					MLPutString(stdlink, buf);
			MLEndPacket(stdlink);
#endif

			MLNextPacket(stdlink);	/* get kernel's reply */
			MLNewPacket(stdlink);		/* throw it away */
			if (!MLError(stdlink)) return MLEUSER;
				
		}
	}
	
	if (err = MLError(stdlink)) {		/* a MathLink error occurred */
		sprintf(buf, "Message[Bisect::mlink, \"%.70s\"]",
				MLErrorMessage(stdlink));
		MLClearError(stdlink);
		MLNewPacket(stdlink);
		MLEvaluate(stdlink, buf);
		MLNextPacket(stdlink);
		MLNewPacket(stdlink);
	}
	
	return err;
}

void bisect(char *expr, char *x, double x0, double x1)
{
	double xmid;
	double y0, y1, ymid;

	char *buf = malloc(strlen(expr) + strlen(x) + 100);
		
	if (evaluate_expr(buf, expr, x, x0, &y0) ||
	  evaluate_expr(buf, expr, x, x1, &y1)) {
		MLPutSymbol(stdlink, "$Failed");
		return;
	}
	
	while (fabs(x1-x0) > .000001)
	{
		xmid = (x0+x1)/2.0;
		if (evaluate_expr(buf, expr, x, xmid, &ymid)) {
			MLPutSymbol(stdlink, "$Failed");
			return;
		}
		
		if (sign(ymid) == sign(y0))
			x0 = xmid, y0 = ymid;
		else
			x1 = xmid, y1 = ymid;
	}

	free(buf);
	
	MLPutReal(stdlink, (fabs(y0) < fabs(y1)) ? x0 : x1);
}


int main(argc, argv)
	int argc; char* argv[];
{
	return MLMain(argc, argv);
}
