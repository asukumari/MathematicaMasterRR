/*	string.c
 *	From D.B. Wagner, "Power Programming with Mathematica:
 *		The Kernel." McGraw-Hill, 1996.
 *	Copyright 1996, David B. Wagner. All rights reserved.
 */

#include "mathlink.h"
#include "string.h"

void stringpeek( char *s )
{
	long len = strlen(s);
	int *charcodes = (int*) calloc( len, sizeof(int) );
	int i;

	for ( i = 0; i < len; i++ )
		charcodes[i] = s[i];
	
	MLPutIntegerList( stdlink, charcodes, len );

	free( charcodes );
}

void bstringpeek( unsigned char *s, long len )
{
	int *charcodes = (int*) calloc( len, sizeof(int) );
	int i;

	for ( i = 0; i < len; i++ )
		charcodes[i] = s[i];
	
	MLPutIntegerList( stdlink, charcodes, len );

	free( charcodes );
}

void ustringpeek( unsigned short *s, long len )
{
	int *charcodes = (int*) calloc( len, sizeof(int) );
	int i;

	for ( i = 0; i < len; i++ )
		charcodes[i] = s[i];
	
	MLPutIntegerList( stdlink, charcodes, len );

	free( charcodes );
}

void string2ints( char *s )
{
	long len = strlen(s);
	int *charcodes = (int*) calloc(len, sizeof(int));
	MLStringPosition pos;
	int i = 0;

	MLforString( s, pos ) {
		charcodes[i++] = MLStringChar( pos );
	}
	
	MLPutIntegerList( stdlink, charcodes, i );

	free( charcodes );
}

void ints2string( int charcodes[], long nints )
{
	int i, size = 0;
	char *s, *p;

	for( i = 0; i < nints; i++)
		size += MLPutCharToString(charcodes[i], NULL);

	p = s = (char*)malloc(size + 1);
	for( i = 0; i < nints; i++)
		MLPutCharToString(charcodes[i], &p);
	*p = '\0';
	MLPutString(stdlink, s);
	free(s);
}
	

int main(argc, argv)
	int argc; char* argv[];
{
	return MLMain(argc, argv);
}
